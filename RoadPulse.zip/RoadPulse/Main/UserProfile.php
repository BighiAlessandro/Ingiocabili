<?php
include '../db.php'; 

$sql = "SELECT * FROM account"; 
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "Id: " . $row["id"] . " - Nome: " . $row["username"] . " - Email: " . $row["email"] . "<br>";
    }
} else {
    echo "Nessun utente trovato.";
}
?>