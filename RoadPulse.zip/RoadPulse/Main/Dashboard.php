<?php
session_start();

if (!isset($_SESSION['token'])) {
    header("Location: /RoadPulse/login/login.php");
    exit;
}

// Connessione al database
$conn = new mysqli("localhost", "root", "", "roadpulse");
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Recupera la tratta selezionata tramite GET, default 1
$street_id = isset($_GET['street_id']) ? intval($_GET['street_id']) : 1;

// Recupera la tratta selezionata dal database
$stmt = $conn->prepare("SELECT city_start, city_end FROM street WHERE id = ?");
$stmt->bind_param("i", $street_id);
$stmt->execute();
$stmt->bind_result($city_start, $city_end);
$stmt->fetch();
$stmt->close();


?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Homepage</title>
    <style>
      #map {
        height: 30vh;
        width: 40%;
      }
      /* MODAL STYLES */
      .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
      }
      .modal-content {
        background-color: #fefefe;
        margin: 10% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 70vw;
        max-width: 900px;
        border-radius: 8px;
        position: relative;
        display: flex;
        gap: 24px;
      }
      .close {
        color: #aaa;
        position: absolute;
        right: 16px;
        top: 8px;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
      }
      .close:hover,
      .close:focus {
        color: #000;
        text-decoration: none;
        cursor: pointer;
      }
    </style>
</head>
<body>
    <div id="map"></div>
    <button type="button" onclick="openCommentsModal()">Commenti</button>

    <h1>Meteo a Roma</h1>
    <div id="weather"></div>

    <!-- MODAL COMMENTI -->
    <div id="commentsModal" class="modal">
      <div class="modal-content">
        <span class="close" onclick="closeCommentsModal()">&times;</span>
        <!-- Colonna Mappa -->
        <div style="flex: 1; border-right: 1px solid #ccc; padding-right: 16px; display: flex; flex-direction: column; align-items: center;">
          <h2 style="margin-bottom: 8px;">
            <?php echo htmlspecialchars($city_start) . " - " . htmlspecialchars($city_end); ?>
          </h2>
          <div id="modalMap" style="width: 100%; height: 300px; border-radius: 8px; border: 1px solid #ddd;"></div>
        </div>
        <!-- Colonna Commenti -->
        <div style="flex: 1; padding-left: 16px;">
          <h2>Commenti sull'itinerario</h2>
          <div id="commentsList">
            <p><strong>Mario:</strong> Bellissimo percorso!</p>
            <p><strong>Giulia:</strong> Consiglio di fermarsi al Circo Massimo!</p>
          </div>
          <form id="commentForm">
            <textarea id="commentText" rows="3" style="width:100%;" placeholder="Scrivi un commento..."></textarea><br>
            <button type="submit">Invia</button>
          </form>
        </div>
      </div>
    </div>

    <script>
      function initMap() {
        const roma = { lat: 41.9028, lng: 12.4964 };
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 13,
          center: roma,
        });

        const directionsService = new google.maps.DirectionsService();
        const directionsRenderer = new google.maps.DirectionsRenderer({ map: map });

        directionsService.route(
          {
            origin: { lat: 41.8902, lng: 12.4922 }, // Colosseo
            destination: { lat: 41.8947, lng: 12.4811 }, // Piazza Venezia
            waypoints: [
              { location: { lat: 41.8865, lng: 12.4883 }, stopover: true }, // Circo Massimo
              { location: { lat: 41.8830, lng: 12.4863 }, stopover: true }  // Bocca della Verità
            ],
            travelMode: google.maps.TravelMode.DRIVING,
          },
          (response, status) => {
            if (status === "OK") {
              directionsRenderer.setDirections(response);
            } else {
              alert("Errore nella richiesta: " + status);
            }
          }
        );
      }

      // Inizializza la mappa nella modal
      function initModalMap() {
        const roma = { lat: 41.9028, lng: 12.4964 };
        const map = new google.maps.Map(document.getElementById("modalMap"), {
          zoom: 13,
          center: roma,
        });

        const directionsService = new google.maps.DirectionsService();
        const directionsRenderer = new google.maps.DirectionsRenderer({ map: map });

        directionsService.route(
          {
            origin: { lat: 41.8902, lng: 12.4922 }, // Colosseo
            destination: { lat: 41.8947, lng: 12.4811 }, // Piazza Venezia
            waypoints: [
              { location: { lat: 41.8865, lng: 12.4883 }, stopover: true }, // Circo Massimo
              { location: { lat: 41.8830, lng: 12.4863 }, stopover: true }  // Bocca della Verità
            ],
            travelMode: google.maps.TravelMode.DRIVING,
          },
          (response, status) => {
            if (status === "OK") {
              directionsRenderer.setDirections(response);
            }
          }
        );
      }

      function openCommentsModal() {
        document.getElementById('commentsModal').style.display = 'block';
        setTimeout(initModalMap, 200);
      }
      function closeCommentsModal() {
        document.getElementById('commentsModal').style.display = 'none';
      }
      // Chiudi la modal se clicchi fuori dal contenuto
      window.onclick = function(event) {
        const modal = document.getElementById('commentsModal');
        if (event.target == modal) {
          modal.style.display = "none";
        }
      }
      // (Facoltativo) Gestione invio commento (solo frontend)
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('commentForm').onsubmit = function(e) {
          e.preventDefault();
          const text = document.getElementById('commentText').value.trim();
          if (text) {
            const div = document.createElement('p');
            div.innerHTML = `<strong>Tu:</strong> ${text}`;
            document.getElementById('commentsList').appendChild(div);
            document.getElementById('commentText').value = '';
          }
        }
      });
    </script>
    <script>
    const apiKey = "7616323a45af9153f421313a7f4ae1d1";
    const city = "Rome,IT";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=it`;

    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error("Errore nella richiesta meteo");
        }
        return response.json();
      })
      .then(data => {
        const weatherDiv = document.getElementById("weather");
        const temp = data.main.temp;
        const description = data.weather[0].description;
        const humidity = data.main.humidity;
        const icon = data.weather[0].icon;

        weatherDiv.innerHTML = `
          <p><strong>Temperatura:</strong> ${temp}°C</p>
          <p><strong>Condizioni:</strong> ${description}</p>
          <p><strong>Umidità:</strong> ${humidity}%</p>
          <img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="Icona meteo">
        `;
      })
      .catch(error => {
        console.error(error);
        document.getElementById("weather").innerText = "Impossibile recuperare il meteo.";
      });
  </script>
  <script
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB_cEu5Bqsuvs4b1kWBP4vxZdU1vZJOlNI&callback=initMap&libraries=places"
  async defer>
</script>
</body>
</html>
